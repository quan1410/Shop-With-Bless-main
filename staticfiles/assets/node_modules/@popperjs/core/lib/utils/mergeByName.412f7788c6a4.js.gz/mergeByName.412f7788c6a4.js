export default function mergeByName(modifiers) {
    var merged = modifiers.reduce(function(merged, current) {
        var existing = merged[current.name];
        merged[current.name] = existing ? Object.assign(Object.assign(Object.assign({}, existing), current), {}, {
            options: Object.assign(Object.assign({}, existing.options), current.options),
            data: Object.assign(Object.assign({}, existing.data), current.data)
        }) : current;
        return merged;
    }, {}); // IE11 does not support Object.values

    return Object.keys(merged).map(function(key) {
        return merged[key];
    });
}